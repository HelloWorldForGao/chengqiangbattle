import random
import time

def exit_game():
    print('退出游戏',end='')
    time.sleep(1)
    print('.',end='')
    time.sleep(1)
    print('.',end='')
    time.sleep(1)
    print('.',end='')
    return 0
def little_san(live):
    a = random.choice([1,1,1,1,1,2,2,2,2,3,3,3,4,4,5]) * 3
    return [live - a,a]
def bomb(live):
    return live - 10
def big_san(live):
    return live - 15
def live_bag(live):
    return live + 5
def get_results_to_player(number,enemylive,yourlive,energy):
    if number == 1:
        if energy < 5:
            return [bomb(enemylive),energy + 1]
        else:
            return [bomb(enemylive),5]
    elif number == 2:
        a = little_san(enemylive)
        if energy >= 1:
            return [a[0],energy - 1,a[1]]
        else:
            return [None,None]
    elif number == 3:
        if energy >= 5:
            return [big_san(enemylive),energy - 5]
        else:
            return [None,None]
    else:
        if energy < 5:
            return [live_bag(yourlive),energy + 1]
        else:
            return [live_bag(yourlive),5]
def get_results_to_enemy(yourlive,enemylive,energy):
    if enemylive >= 50:
        if energy <= 2:
            return [bomb(yourlive),energy + 1,1]
        elif energy <= 4:
            number = random.choice([1,1,2])
            if number == 1:
                return [bomb(yourlive),energy + 1,1]
            else:
                a = little_san(yourlive)
                return [a[0],energy - 1,a[1],2]
        elif energy >= 5:
            number = random.choice([1,2,3,3,3])
            if number == 1:
                return [bomb(yourlive),energy + 1,1]
            elif number == 2:
                a = little_san(yourlive)
                return [a[0],energy - 1,a[1],2]
            else:
                return [big_san(yourlive),energy - 5,3]
        else:
            pass
    else:
        if energy <= 2:
            number = random.choice([1,1,4])
            if number == 1:
                return [bomb(yourlive),energy + 1,1]
            else:
                return [live_bag(enemylive),energy + 1,4]
        elif energy <= 4:
            number = random.choice([1,1,2,4,4])
            if number == 1:
                return [bomb(yourlive),energy + 1,1]
            elif number == 2:
                a = little_san(yourlive)
                return [a[0],energy - 1,a[1],2]
            else:
                return [live_bag(enemylive),energy + 1,4]
        elif energy >= 5:
            number = random.choice([1,2,2,3,3,3,4,4])
            if number == 1:
                return [bomb(yourlive),energy + 1,1]
            elif number == 2:
                a = little_san(yourlive)
                return [a[0],energy - 1,a[1],2]
            elif number == 3:
                return [big_san(yourlive),energy - 5,3]
            else:
                return [live_bag(enemylive),energy + 1,4]
        else:
            pass
def isWin(enemylive):
    if enemylive <= 0:
        return True
    else:
        return False
def isLose(yourlive):
    if yourlive <= 0:
        return True
    else:
        return False

