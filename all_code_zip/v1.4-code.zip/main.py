import tkinter as tk
from pgzrun import *
import random
import time
import battle as ba

WIDTH = 800
HEIGHT = 600
TITLE = '城墙守卫战'

myLive = 0
enemyLive = 0
myEnergy = 0
enemyEnergy = 0
isBattle = 0
huihe = 0
text = []

ExitPng = Actor('exit',(50,500)) # type: ignore
StartPng = Actor('start',(600,500)) # type: ignore
ChengqiangPng = Actor('chengqiangbattle') # type: ignore
TextPng = Actor('none',(400,450)) # type: ignore
Enegy1Png = Actor('enegy',(90,160)) # type: ignore
Enegy2Png = Actor('enegy',(640,160)) # type: ignore

Bomb = Actor('bomb',(50,500)) # type: ignore
LittleSan = Actor('little_san',(150,500)) # type: ignore
BigSan = Actor('big_san',(250,500)) # type: ignore
LiveBag = Actor('live_bag',(350,500))
AboutWeapon = Actor('about_weapon',(575,500))
Click = Actor('click1',(750,550))

def about_us() -> str:
    """return about us"""
    return '城墙守卫战v1.0\nby长草原玩家\n '
class bool_check:
    def __init__(self):
        self.playerActionDone = False
        self.actionDonesCounter = 0
    def textIsZero(self):
        global text
        if len(text) == 0:
            return True
        else:
            return False
    def textIsntZero(self):
        global text
        if len(text) != 0:
            return True
        else:
            return False
#    def check(self,name):
#        global text
#        if name == 'textIsZero':
#            self.textIsZero()

bools = bool_check()
weapons = {'Bomb':['对敌人造成10点伤害','回复1点能量'],'LittleSan' : ['对敌人造成3至15点伤害','消耗1点能量'],'BigSan' : ['对敌人造成15点伤害','消耗5点能量'],'LiveBag' : ['回复5点血','回复1点能量']}
weapon_now = ['将指针悬停在一个技能上','以查看它的各项属性']
counter = 0
counter_ = 0

def bind_check(actor_,before_after : list,pos):
    """bind actor to check mouse collidepoint,if True,change actor's image to before_after[1],else,change actor's image to before_after[0]"""
    if actor_.collidepoint(pos):
        actor_.image = before_after[1]
    else:
        actor_.image = before_after[0]
def change_weapon(pos):
    global weapon_now,weapons
    global Bomb,LittleSan,BigSan,LiveBag
    if Bomb.collidepoint(pos):
        weapon_now = weapons['Bomb']
    elif LittleSan.collidepoint(pos):
        weapon_now = weapons['LittleSan']
    elif BigSan.collidepoint(pos):
        weapon_now = weapons['BigSan']
    elif LiveBag.collidepoint(pos):
        weapon_now = weapons['LiveBag']
    else:
        weapon_now = ['将指针悬停在一个技能上','以查看它的各项属性']
def change_image(actor_,images):
    index_ = 0
    image_ = actor_.image
    if images.count(image_) == 0:
        raise ValueError('Actor\'s image is not in the list!')
    else:
        index_ = images.index(image_)
        if images[index_] == images[-1]:
            actor_.image = images[1]
            image_ = images[1]
            index_ = 1
        else:
            actor_.image = images[index_ + 1]
            image_ = images[index_ + 1]
            index_ += 1
def new_enemy_action():
    """enemy action"""
    global myLive
    global enemyEnergy,enemyLive
    global text
    a = ba.get_results_to_enemy(myLive,enemyLive,enemyEnergy)
    if a[-1] == 1:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了炸弹')
        if a[0] >= 0:
            text.append('你还剩'+str(a[0])+'点血')
        else:
            text.append('你还剩0点血')
    elif a[-1] == 2:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了散弹')
        text.append('造成了'+str(a[2])+'点伤害')
        if a[0] >= 0:
            text.append('你还剩'+str(a[0])+'点血')
        else:
            text.append('你还剩0点血')
    elif a[-1] == 3:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了自瞄散弹')
        if a[0] >= 0:
            text.append('你还剩'+str(a[0])+'点血')
        else:
            text.append('你还剩0点血')
    else:
        enemyLive = a[0]
        enemyEnergy = a[1]
        text.append('对方使用了回血包')
        text.append('对方还剩' + str(a[0]) + '点血')
def start_battle():
    """battle init"""
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    myLive = 100
    enemyLive = 100
    myEnergy = 3
    enemyEnergy = 3
    huihe = 1
def draw():
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    global text
    global weapon_now
    global counter,counter_
    screen.blit('background',(0,0)) # type: ignore
    if isBattle == 0:
        ExitPng.y = 500
        ExitPng.draw()
        StartPng.draw()
        ChengqiangPng.top = 0
        ChengqiangPng.left = 0
        ChengqiangPng.draw()
    else:
        Enegy1Png.draw()
        Enegy2Png.draw()
        ExitPng.y = 50
        ExitPng.draw()
        Bomb.draw()
        LittleSan.draw()
        BigSan.draw()
        LiveBag.draw()
        AboutWeapon.draw()
        screen.draw.text(str(myLive)+'% / 100%',(50,100),color='black',fontname='main') # type: ignore
        screen.draw.text(str(enemyLive)+'% / 100%',(600,100),color='black',fontname='main') # type: ignore
        screen.draw.text(str(myEnergy) + '/5',(140,160),color='black',fontname='main') # type: ignore
        screen.draw.text(str(enemyEnergy) + '/5',(680,160),color='black',fontname='main') # type: ignore
        screen.draw.text('第'+str(huihe)+'回合',(400,50),color='black',fontname='main') # type: ignore
        screen.draw.text(weapon_now[0],(445,477.5),color = 'black',fontname = 'main',fontsize = 15)
        screen.draw.text(weapon_now[1],(445,504),color = 'black',fontname = 'main',fontsize = 15)
    if len(text) != 0:
        TextPng.image = 'newtext'
        TextPng.draw()
        Click.draw()
        screen.draw.text(text[0],(50,360),color='black',fontname='main') # type: ignore
    else:
        TextPng.image = 'none'
    if counter_ >= 100:
        screen.draw.text('点这里！',(700,500),color = 'black',fontname = 'main',fontsize = 15)
    
        
def on_mouse_down(button,pos):
    global StartPng
    global ExitPng
    global isBattle
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    global text
    global bools
    global counter,counter_
    if button == 1:
        if len(text) == 0:
            if ExitPng.collidepoint(pos):
                if isBattle == 0:
                    exit()
                else:
                    myLive = 0
            if StartPng.collidepoint(pos):
                start_battle()
                isBattle = 1
                music.stop() # type: ignore
                music.play('battle_music') # type: ignore
            if isBattle == 1:
                if Bomb.collidepoint(pos):
                    a = ba.get_results_to_player(1,enemyLive,myLive,myEnergy)
                    if a[0] != None:
                        #text.append('第 '+str(huihe)+' 回合')
                        #text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                        #text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                        text.append('对敌人释放了炸弹')
                        if a[0] >= 0:
                            text.append('敌人还剩'+str(a[0])+'点血')
                        else:
                            text.append('敌人还剩0点血')
                        enemyLive=a[0]
                        myEnergy=a[1]
                        bools.playerActionDone = True
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
                if LittleSan.collidepoint(pos):
                    a = ba.get_results_to_player(2,enemyLive,myLive,myEnergy)
                    if a[0] !=  None:
                        #text.append('第 '+str(huihe)+' 回合')
                        #text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                        #text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                        text.append('对敌人释放了散弹')
                        if a[0] >= 0:
                            text.append('敌人还剩'+str(a[0])+'点血')
                        else:
                            text.append('敌人还剩0点血')
                        enemyLive =a[0]
                        myEnergy = a[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
                if BigSan.collidepoint(pos):
                    a = ba.get_results_to_player(3,enemyLive,myLive,myEnergy)
                    if a[0] !=  None:
                        #text.append('第 '+str(huihe)+' 回合')
                        #text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                        #text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                        text.append('对敌人释放了自瞄炸弹')
                        if a[0] >= 0:
                            text.append('敌人还剩'+str(a[0])+'点血')
                        else:
                            text.append('敌人还剩0点血')
                        enemyLive=a[0]
                        myEnergy=a[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
                if LiveBag.collidepoint(pos):
                    a = ba.get_results_to_player(4,enemyLive,myLive,myEnergy)
                    if myLive <= 95:
                        #text.append('第 '+str(huihe)+' 回合')
                        #text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                        #text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                        text.append('使用了一次回血包')
                        text.append('你还剩'+str(a[0])+'点血')
                        myLive=a[0]
                        myEnergy=a[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的血量大于95，无需回血')
        else:
            text.pop(0)
            draw()
            counter_ = 0
def on_mouse_move(pos):
    bind_check(Bomb,['bomb','selete_bomb'],pos)
    bind_check(LittleSan,['little_san','selete_little_san'],pos)
    bind_check(BigSan,['big_san','selete_big_san'],pos)
    bind_check(ExitPng,['exit','selete_exit'],pos)
    bind_check(StartPng,['start','selete_start'],pos)
    bind_check(LiveBag,['live_bag','selete_live_bag'],pos)
    change_weapon(pos)
def update():
    global myLive
    global enemyLive
    global isBattle
    global text
    global bools
    global counter,counter_
    global huihe
    if isBattle == 1:
        if ba.isLose(myLive):
            if ba.isWin(enemyLive):
                if bools.textIsZero():
                    text.append('平局！')
                    isBattle = 0
                    music.stop() # type: ignore
                    music.play('hobby_music') # type: ignore
            else:
                if bools.textIsZero():
                    text.append('你输了！')
                    isBattle = 0
                    music.stop() # type: ignore
                    music.play('hobby_music') # type: ignore
        elif ba.isWin(enemyLive):
            if bools.textIsZero():
                text.append('你赢了！')
                isBattle = 0
                music.stop() # type: ignore
                music.play('hobby_music') # type: ignore
        else:
            pass
    if counter % 20 == 0:
        if Click.image == 'click1':
            Click.image = 'click2'
        elif Click.image == 'click2':
            Click.image = 'click3'
        else:
            Click.image = 'click1'
    counter += 1
    if bools.textIsntZero():
        counter_ += 1
    if bools.playerActionDone:
        bools.actionDonesCounter = counter
        new_enemy_action()
        huihe += 1
        bools.playerActionDone = False
    
print(about_us())
music.play('hobby_music') # type: ignore
go()
