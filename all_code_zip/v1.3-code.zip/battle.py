import random
import time

def exit_game():
    print('退出游戏',end='')
    time.sleep(1)
    print('.',end='')
    time.sleep(1)
    print('.',end='')
    time.sleep(1)
    print('.',end='')
    return 0
def little_san(live):
    a = random.randint(3,5)*3
    return [live - a,a]
def bomb(live):
    return live - 10
def big_san(live):
    return live - 15
def live_bag(live):
    return live + 5
def choose_things(number,enemylive,energy):
    if number == 1:
        print('对敌人释放了炸弹')
        print('敌人还剩'+str(bomb(enemylive))+'点血量')
        return [bomb(enemylive),energy + 1]
    elif number == 2:
        if energy >= 1:
            a = little_san(enemylive)
            print('对敌人释放了散弹')
            print('造成了'+str(a[1])+'点伤害')
            print('敌人还剩'+str(a[0])+'点血量')
            return [a[0],energy - 1,a[1]]
        else:
            print('你的能量不足，还剩'+str(energy)+'点能量')
            return [None,None]
    else:
        if energy >= 1:
            print('对敌人释放了自瞄散弹')
            print('敌人还剩'+str(big_san(enemylive))+'点血量')
            return [big_san(enemylive),energy - 5]
        else:
            print('你的能量不足，还剩'+str(energy)+'点能量')
            return [None,None]
def get_results_to_player(number,enemylive,energy):
    if number == 1:
        return [bomb(enemylive),energy + 1]
    elif number == 2:
        a = little_san(enemylive)
        if energy >= 1:
            return [a[0],energy - 1,a[1]]
        else:
            return [None,None]
    else:
        if energy >= 5:
            return [big_san(enemylive),energy - 5]
        else:
            return [None,None]
def enemy_choose(yourlive,energy):
    if energy <= 2:
        print('对你释放了炸弹')
        print('你还剩'+str(bomb(yourlive))+'点血量')
        return [bomb(yourlive),energy + 1]
    elif energy <= 4:
        number = random.choice([1,2])
        if number == 1:
            print('对你释放了炸弹')
            print('你还剩'+str(bomb(yourlive))+'点血量')
            return [bomb(yourlive),energy + 1]
        else:
            a = little_san(yourlive)
            print('对你释放了散弹')
            print('造成了'+str(a[1])+'点伤害')
            print('你还剩'+str(a[0])+'点血量')
            return [a[0],energy - 1,a[1]]
    elif energy >= 5:
        number = random.choice([1,2,3])
        if number == 1:
            print('对你释放了炸弹')
            print('你还剩'+str(bomb(yourlive))+'点血量')
            return [bomb(yourlive),energy + 1]
        elif number == 2:
            a = little_san(yourlive)
            print('对你释放了散弹')
            print('造成了'+str(a[1])+'点伤害')
            print('你还剩'+str(a[0])+'点血量')
            return [a[0],energy - 1,a[1]]
        else:
            print('对你释放了自瞄散弹')
            print('你还剩'+str(bomb(yourlive))+'点血量')
            return [big_san(yourlive),energy - 5]
    else:
        pass
def get_results_to_enemy(yourlive,energy):
    if energy <= 2:
        return [bomb(yourlive),energy + 1,1]
    elif energy <= 4:
        number = random.choice([1,2])
        if number == 1:
            return [bomb(yourlive),energy + 1,1]
        else:
            a = little_san(yourlive)
            return [a[0],energy - 1,a[1],2]
    elif energy >= 5:
        number = random.choice([1,2,3])
        if number == 1:
            return [bomb(yourlive),energy + 1,1]
        elif number == 2:
            a = little_san(yourlive)
            return [a[0],energy - 1,a[1],2]
        else:
            return [big_san(yourlive),energy - 5,3]
    else:
        pass
def isWin(enemylive):
    if enemylive <= 0:
        return True
    else:
        return False
def isLose(yourlive):
    if yourlive <= 0:
        return True
    else:
        return False

