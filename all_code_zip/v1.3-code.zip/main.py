import tkinter as tk
from pgzrun import *
import random
import time
import battle as ba

WIDTH = 800
HEIGHT = 600
TITLE = '城墙守卫战'

myLive = 0
enemyLive = 0
myEnergy = 0
enemyEnergy = 0
isBattle = 0
huihe = 0
text = []

ExitPng = Actor('exit',(50,500)) # type: ignore
StartPng = Actor('start',(600,500)) # type: ignore
ChengqiangPng = Actor('chengqiangbattle') # type: ignore
TextPng = Actor('none',(400,450)) # type: ignore
Enegy1Png = Actor('enegy',(300,500)) # type: ignore
Enegy2Png = Actor('enegy',(500,500)) # type: ignore

Bomb = Actor('bomb',(50,500)) # type: ignore
LittleSan = Actor('little_san',(150,500)) # type: ignore
BigSan = Actor('big_san',(250,500)) # type: ignore

def about_us():
    return ' 城墙守卫战v1.0 \n by长草原玩家 \n '
def new_enemy_action():
    global myLive
    global enemyEnergy
    a = ba.get_results_to_enemy(myLive,enemyEnergy)
    if a[len(a) - 1] == 1:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了炸弹')
        text.append('你还剩'+str(a[0])+'点血')
    elif a[len(a) - 1] == 2:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了散弹')
        text.append('造成了'+str(a[2])+'点伤害')
        text.append('你还剩'+str(a[0])+'点血')
    else:
        myLive = a[0]
        enemyEnergy = a[1]
        text.append('对你释放了自瞄散弹')
        text.append('你还剩'+str(a[0])+'点血')
def start_battle():
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    myLive = 100
    enemyLive = 100
    myEnergy = 3
    enemyEnergy = 3
    huihe = 1
def draw():
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    global text
    screen.blit('background',(0,0)) # type: ignore
    if isBattle == 0:
        ExitPng.y = 500
        ExitPng.draw()
        StartPng.draw()
        ChengqiangPng.top = 0
        ChengqiangPng.left = 0
        ChengqiangPng.draw()
    else:
        Enegy1Png.draw()
        Enegy2Png.draw()
        ExitPng.y = 50
        ExitPng.draw()
        Bomb.draw()
        LittleSan.draw()
        BigSan.draw()
        screen.draw.text(str(myLive)+'% / 100%',(50,100),color='black',fontname='main') # type: ignore
        screen.draw.text(str(enemyLive)+'% / 100%',(600,100),color='black',fontname='main') # type: ignore
        screen.draw.text(str(myEnergy),(350,500),color='black',fontname='main') # type: ignore
        screen.draw.text(str(enemyEnergy),(550,500),color='black',fontname='main') # type: ignore
        screen.draw.text('第'+str(huihe)+'回合',(400,50),color='black',fontname='main') # type: ignore
    if len(text) != 0:
        TextPng.image = 'newtext'
        TextPng.draw()
        screen.draw.text(text[0],(50,360),color='black',fontname='main') # type: ignore
    else:
        TextPng.image = 'none'
        
def on_mouse_down(button,pos):
    global StartPng
    global ExitPng
    global isBattle
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    global text
    if button == 1:
        if len(text) == 0:
            if ExitPng.collidepoint(pos):
                if isBattle == 0:
                    exit()
                else:
                    myLive = 0
            if StartPng.collidepoint(pos):
                start_battle()
                isBattle = 1
                music.stop() # type: ignore
                music.play('battle_music') # type: ignore
            if isBattle == 1:
                if Bomb.collidepoint(pos):
                    text.append('第 '+str(huihe)+' 回合')
                    text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                    text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                    if ba.get_results_to_player(1,enemyLive,myEnergy)[0] != False:
                        text.append('对敌人释放了炸弹')
                        text.append('敌人还剩'+str(ba.get_results_to_player(1,enemyLive,myEnergy)[0])+'点血')
                        enemyLive=ba.get_results_to_player(1,enemyLive,myEnergy)[0]
                        myEnergy=ba.get_results_to_player(1,enemyLive,myEnergy)[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
                if LittleSan.collidepoint(pos):
                    text.append('第 '+str(huihe)+' 回合')
                    text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                    text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                    if ba.get_results_to_player(2,enemyLive,myEnergy)[0] != None:
                        a = ba.get_results_to_player(2,enemyLive,myEnergy)
                        text.append('对敌人释放了散弹')
                        text.append('敌人还剩'+str(ba.get_results_to_player(2,enemyLive,myEnergy)[0])+'点血')
                        enemyLive =a [0]
                        myEnergy = a[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
                if BigSan.collidepoint(pos):
                    text.append('第 '+str(huihe)+' 回合')
                    text.append('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                    text.append('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                    if ba.get_results_to_player(3,enemyLive,myEnergy)[0] != None:
                        text.append('对敌人释放了自瞄炸弹')
                        text.append('敌人还剩'+str(ba.get_results_to_player(3,enemyLive,myEnergy)[0])+'点血')
                        enemyLive=ba.get_results_to_player(3,enemyLive,myEnergy)[0]
                        myEnergy=ba.get_results_to_player(3,enemyLive,myEnergy)[1]
                        new_enemy_action()
                        huihe += 1
                    else:
                        text.append('你的能量不足，还剩'+str(myEnergy)+'点能量')
        else:
            text.pop(0)
            draw()
def on_mouse_move(pos):
    if Bomb.collidepoint(pos):
        Bomb.image = 'selete_bomb'
    else:
        Bomb.image = 'bomb'
    if LittleSan.collidepoint(pos):
        LittleSan.image = 'selete_little_san'
    else:
        LittleSan.image = 'little_san'
    if BigSan.collidepoint(pos):
        BigSan.image = 'selete_big_san'
    else:
        BigSan.image = 'big_san'
def update():
    global myLive
    global enemyLive
    global isBattle
    global text
    if isBattle == 1:
        if ba.isLose(myLive):
            if ba.isWin(enemyLive):
                text.append('平局！')
                isBattle = 0
                music.stop() # type: ignore
                music.play('hobby_music') # type: ignore
            else:
                text.append('你输了！')
                isBattle = 0
                music.stop() # type: ignore
                music.play('hobby_music') # type: ignore
        elif ba.isWin(enemyLive):
            text.append('你赢了！')
            isBattle = 0
            music.stop() # type: ignore
            music.play('hobby_music') # type: ignore
        else:
            pass

print(about_us())
music.play('hobby_music') # type: ignore
go()
