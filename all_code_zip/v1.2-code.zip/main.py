import tkinter as tk
import pgzrun
import random
import time
import battle as ba

WIDTH = 800
HEIGHT = 600
TITLE = '城墙守卫战'

myLive = 0
enemyLive = 0
myEnergy = 0
enemyEnergy = 0
isBattle = 0
huihe = 0

ExitPng = Actor('exit',(50,500))
StartPng = Actor('start',(700,500))
ChengqiangPng = Actor('chengqiangbattle')
TextPng = Actor('none',(400,450))
Enegy1Png = Actor('enegy',(300,500))
Enegy2Png = Actor('enegy',(500,500))

Bomb = Actor('bomb',(50,500))
LittleSan = Actor('little_san',(150,500))
BigSan = Actor('big_san',(250,500))

sign_up=[None,None,False]
about_user=[None,None,None,None,None]

file1 = open('user.txt',encoding='UTF-8')
read1 = file1.readlines()
users=[]

for i in read1:
    users.append(i.replace('\n','').split(' '))

win=tk.Tk()
win.geometry('400x200')
win.title('登录')

label1=tk.Label(win,text='输入用户名')
label1.pack()
entry1=tk.Entry(win,text='输入用户名...')
entry1.pack()
label2=tk.Label(win,text='输入密码')
label2.pack()
entry2=tk.Entry(win,text='输入密码...')
entry2.pack()

def about_us():
    return ' 城墙守卫战v1.0 \n by长草原玩家 \n '
def check_user():
    global win
    global label1
    global entry1
    global label2
    global entry2
    global users
    global sign_up
    global about_user
    for i in range(len(users)):
        if users[i][0] == entry1.get():
            if users[i][1] == entry2.get():
                print("已登录")
                sign_up[0] = users[i][0]
                sign_up[1] = users[i][1]
                sign_up[2] = True
                about_user[0] = users[i][2]
                about_user[1] = users[i][3]
                about_user[2] = users[i][4]
                about_user[3] = users[i][5]
                about_user[4] = users[i][6]
                win.destroy()
                print(about_user)
                return 0
            else:
                print("密码错误")
                return 0
    print("未找到此用户")

button1=tk.Button(win,text='提交结果',command=check_user)
button1.pack()
def start_battle():
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    myLive = 100
    enemyLive = 100
    myEnergy = 3
    enemyEnergy = 3
    huihe = 0
def draw():
    global sign_up
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    if sign_up[2] == False:
        screen.blit('non_sign_up',(0,0))
    else:
        screen.blit('main_background',(0,0))
        if isBattle == 0:
            ExitPng.y = 500
            ExitPng.draw()
            StartPng.draw()
            ChengqiangPng.top = 0
            ChengqiangPng.left = 0
            ChengqiangPng.draw()
        else:
            Enegy1Png.draw()
            Enegy2Png.draw()
            ExitPng.y = 50
            ExitPng.draw()
            Bomb.draw()
            LittleSan.draw()
            BigSan.draw()
            screen.draw.text(str(myLive)+'% / 100%',(50,50),color='black',fontname='main')
            screen.draw.text(str(enemyLive)+'% / 100%',(600,50),color='black',fontname='main')
            screen.draw.text(str(myEnergy),(350,500),color='black',fontname='main')
            screen.draw.text(str(enemyEnergy),(550,500),color='black',fontname='main')
            screen.draw.text('第'+str(huihe)+'回合',(400,50),color='black',fontname='main')
        
def on_mouse_down(button,pos):
    global sign_up
    global win
    global StartPng
    global ExitPng
    global isBattle
    global myLive
    global enemyLive
    global myEnergy
    global enemyEnergy
    global huihe
    if sign_up[2] == False:
        win.mainloop()
    else:
        if ExitPng.collidepoint(pos):
            if isBattle == 0:
                exit()
            else:
                myLive = 0
        if StartPng.collidepoint(pos):
            start_battle()
            isBattle = 1
            music.stop()
            music.play('battle_music')
        if isBattle == 1:
            if Bomb.collidepoint(pos):
                print('第 '+str(huihe)+' 回合')
                print('==================================================')
                print('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                print('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                if ba.choose_things(1,enemyLive,myEnergy)[0] != False:
                    enemyLive=ba.choose_things(1,enemyLive,myEnergy)[0]
                    myEnergy=ba.get_results_to_player(1,enemyLive,myEnergy)[1]
                    time.sleep(1)
                    myLive=ba.enemy_choose(myLive,enemyEnergy)[0]
                    enemyEnergy=ba.get_results_to_enemy(myLive,enemyEnergy)[1]
                    time.sleep(1)
                else:
                    pass
            if LittleSan.collidepoint(pos):
                print('第 '+str(huihe)+' 回合')
                print('==================================================')
                print('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                print('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                if ba.choose_things(2,enemyLive,myEnergy)[0] != False:
                    enemyLive=ba.choose_things(2,enemyLive,myEnergy)[0]
                    myEnergy=ba.get_results_to_player(2,enemyLive,myEnergy)[1]
                    time.sleep(1)
                    myLive=ba.enemy_choose(myLive,enemyEnergy)[0]
                    enemyEnergy=ba.get_results_to_enemy(myLive,enemyEnergy)[1]
                    time.sleep(1)
                else:
                    pass
            if BigSan.collidepoint(pos):
                print('第 '+str(huihe)+' 回合')
                print('==================================================')
                print('你的血量：'+str(myLive)+'你的能量：'+str(myEnergy))
                print('敌人的血量：'+str(enemyLive)+'敌人的能量：'+str(enemyEnergy))
                if ba.choose_things(3,enemyLive,myEnergy)[0] != False:
                    enemyLive=ba.choose_things(3,enemyLive,myEnergy)[0]
                    myEnergy=ba.get_results_to_player(3,enemyLive,myEnergy)[1]
                    time.sleep(1)
                    myLive=ba.enemy_choose(myLive,enemyEnergy)[0]
                    enemyEnergy=ba.get_results_to_enemy(myLive,enemyEnergy)[1]
                    time.sleep(1)
                else:
                    pass
            huihe += 1
def update():
    global myLive
    global enemyLive
    global isBattle
    if isBattle == 1:
        if ba.isWin(enemyLive):
            print('你赢了！')
            isBattle = 0
            music.stop()
            music.play('hobby_music')
        if ba.isLose(myLive):
            print('你输了！')
            isBattle = 0
            music.stop()
            music.play('hobby_music')

print(about_us())
music.play('hobby_music')
pgzrun.go()
