from pgzero.runner import main

main()
